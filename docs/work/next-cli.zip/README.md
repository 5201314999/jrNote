## 简介
前端脚手架工具

## 使用方法
第一步: 通过npm私有库全局安装

```npm i next-cli -g```
> 项目已经发布到自建npm私有库上，npm私有库地址: ```http://10.133.145.2:4873/```; npm私有库的使用方法：```http://km.midea.com/?/article/956```


第二步:初始化项目

```next init projectName(项目名称)```
> 项目名称，注意不能包含中文，大写字母，推荐使用下划线，一直回车即可；pc项目模板地址：```https://gitlab.midea.cn/yang/new-next-template/tree/dev```